/**
 * Created by Jayse on 2/22/2017.
 */
"use strict";  // Operate in Strict mode such that variables must be declared before used!

function Enemy(spriteTexture, atX, atY, centerX, centerY, Width, Height) {
    this.kSpeed = 20/60;
    this.rotateSpeed = .01;
    this.mEnemy = new SpriteAnimateRenderable(spriteTexture);
    
    this.mainX = centerX;
    this.mainY = centerY;
    this.mainWidth = Width;
    this.mainHeight = Height;
    
    this.mEnemy.setColor([1, 1, 1, 0]);
    this.mEnemy.getXform().setPosition(atX, atY);
    this.mEnemy.getXform().setSize(12, 9.6);
    this.mEnemy.setSpriteSequence(512, 0,      // first element pixel position: top-left 512 is top of image, 0 is left of image
        204, 164,    // widthxheight in pixels
        5,           // number of elements in this sequence
        0);          // horizontal padding in between
    this.mEnemy.setAnimationType(SpriteAnimateRenderable.eAnimationType.eAnimateSwing);
    this.mEnemy.setAnimationSpeed(30);
    // show each element for mAnimSpeed updates
    GameObject.call(this, this.mEnemy);
    this.setSpeed(this.kSpeed);
    var mRigidCircle = new RigidCircle(this.getXform(), 4);
    mRigidCircle.drawMe = true;
    mRigidCircle.setMass(2);
    mRigidCircle.setAcceleration([0, 0]);
    mRigidCircle.setFriction(0);
    if (Math.random() > 0.5) {
        mRigidCircle.setVelocity([this.kSpeed, 0]);
    } else {
        mRigidCircle.setVelocity([-this.kSpeed, 0]);
    }
    this.setPhysicsComponent(mRigidCircle);

    this.mHasCollision = false;
}
gEngine.Core.inheritPrototype(Enemy, GameObject);

Enemy.prototype.update = function () {
    GameObject.prototype.update.call(this);
    // remember to update this.mEnemy's animation
    this.mEnemy.updateAnimation();
    if(Math.random() > .5){
        if(Math.abs(this.getXform().getRotationInRad() + this.rotateSpeed) <= 1)
            this.getXform().setRotationInRad(this.getXform().getRotationInRad() + this.rotateSpeed);
    }
    else {
        if(Math.abs(this.getXform().getRotationInRad() - this.rotateSpeed) <= 1)
            this.getXform().setRotationInRad(this.getXform().getRotationInRad() - this.rotateSpeed);
    }
    if(this.getPhysicsComponent().getCollided() === true)
    {
        // this.getPhysicsComponent().setVelocity(vec2.negate(this.getPhysicsComponent().getVelocity()));
        // this.getPhysicsComponent.setCollided(false);
    }
    this.checkBounds();
};

Enemy.prototype.flipVelocity = function () {
    var v = this.getPhysicsComponent().getVelocity();
    vec2.scale(v, v, -1);
};

Enemy.prototype.hasCollision = function () {
    this.mHasCollision = true;
};

Enemy.prototype.checkBounds = function(){
    var test = this.getWorldBBox().boundCollideStatus(this.getBBox());
    if(test !== BoundingBox.eboundCollideStatus.eInside){
        switch(test){
            case 0:
                this.deleteMe = true;
                break;
            case 1: //collideleft
                this.setCurrentFrontDir(vec2.fromValues(1,0));
                break;
            case 2://collideRight
                this.setCurrentFrontDir(vec2.fromValues(-1,0));
                break;
            case 4: //top
                this.setCurrentFrontDir(vec2.fromValues(0,-1));
                break;
            case 5://topleft
                this.setCurrentFrontDir(vec2.fromValues(1,-1));
                break;
            case 6://topRight
                this.setCurrentFrontDir(vec2.fromValues(-1,-1));
                break;
            case 8://bottom
                this.setCurrentFrontDir(vec2.fromValues(0,1));
                break;
            case 9://bottomleft
                this.setCurrentFrontDir(vec2.fromValues(1,1));
                break;
            case 10://bottomright
                this.setCurrentFrontDir(vec2.fromValues(-1,1));
                break;
        }
    }
};

Enemy.prototype.getWorldBBox = function(){
    return new BoundingBox(vec2.fromValues(this.mainX, this.mainY), this.mainWidth, this.mainHeight);
};
