
/*jslint node: true, vars: true, evil: true, bitwise: true */
"use strict";

/* global gEngine */

function RigidShape(xf) {
    this.mLine = new LineRenderable();
    this.mLine.setColor([1, 1, 1, 1]);

    this.mXform = xf;
    this.mVelocity = vec2.fromValues(0, 0);
    this.mBoundRadius = 0;
    this.drawBoundCircle = true;
    this.mCollisionInfo = null;
}

RigidShape.prototype.setBoundRadius = function(r) {
    this.mBoundRadius = r;
};
RigidShape.prototype.getBoundRadius = function() {
    return this.mBoundRadius;
};

RigidShape.prototype.setCollisionInfo = function(CI){
    if(this.mCollisionInfo === null)
    {
        this.mCollisionInfo = [];
        this.mCollisionInfo.push(CI)
    }
    else
        this.mCollisionInfo.push(CI);
};

RigidShape.prototype.setVelocity = function(x, y) {
    this.mVelocity[0] = x;
    this.mVelocity[1] = y;
};
RigidShape.prototype.getVelocity = function() { return this.mVelocity;};
RigidShape.prototype.flipVelocity = function() { 
    this.mVelocity[0] = -this.mVelocity[0];
    this.mVelocity[1] = -this.mVelocity[1];
};

RigidShape.prototype.travel = function(dt) {};

RigidShape.prototype.update = function () {
    var dt = gEngine.GameLoop.getUpdateIntervalInSeconds();
    //s += v*t 
    this.travel(dt);
};

RigidShape.prototype.setDrawBoundCircle = function(isTrue){this.drawBoundCircle = isTrue;};

RigidShape.prototype.getDrawBoundCircle = function(){return this.drawBoundCircle;};

RigidShape.prototype.boundTest = function (otherShape, collisionInfo) {
    if(this instanceof RigidCircle && otherShape instanceof RigidCircle) {
        return this.checkCircCirc(otherShape, collisionInfo);
    }
    else if(this instanceof RigidCircle && otherShape instanceof RigidRectangle){
        return otherShape.checkRectCirc(this, collisionInfo);
    }
    else if(this instanceof RigidRectangle && otherShape instanceof RigidCircle) {
        return this.checkRectCirc(otherShape, collisionInfo);
    }
    else if(this instanceof RigidRectangle && otherShape instanceof RigidRectangle) {
        return this.checkRectRect(otherShape, collisionInfo);
    }
};

RigidShape.prototype.draw = function(aCamera) {
    if(this.drawBoundCircle) {
        var len = this.mBoundRadius * 0.5;
        //calculation for the X at the center of the shape
        var x = this.mXform.getXPos();
        var y = this.mXform.getYPos();

        this.mLine.setColor([1, 1, 1, 1]);
        this.mLine.setFirstVertex(x - len, y);  //Horizontal
        this.mLine.setSecondVertex(x + len, y); //
        this.mLine.draw(aCamera);

        this.mLine.setFirstVertex(x, y + len);  //Vertical
        this.mLine.setSecondVertex(x, y - len); //
        this.mLine.draw(aCamera);
    }

    if(this.mCollisionInfo !== null){
        for(var i = 0; i < this.mCollisionInfo.length; i++) {
            this.mLine.setColor([1, 0, 1, 1]);
            this.mLine.setPointSize(15);
            var test = this.mCollisionInfo[i].getStart();
            this.mLine.setFirstVertex(test[0], test[1]);
            test = this.mCollisionInfo[i].getEnd();
            this.mLine.setSecondVertex(test[0], test[1]);
            this.mLine.setDrawVertices(true);
            this.mLine.draw(aCamera);
            this.mCollisionInfo = null;
            this.mLine.setDrawVertices(false);
        }
    }
};

RigidShape.kNumCircleSides = 32;
RigidShape.prototype.drawCircle = function(aCamera, r) {
    var pos = this.mXform.getPosition();
    var prevPoint = vec2.clone(pos);
    var deltaTheta = (Math.PI * 2.0) / RigidShape.kNumCircleSides;
    var theta = deltaTheta;
    prevPoint[0] += r;
    var i, x, y;

    for (i = 1; i <= RigidShape.kNumCircleSides; i++) {
        x = pos[0] + r * Math.cos(theta);
        y = pos[1] +  r * Math.sin(theta);

        this.mLine.setFirstVertex(prevPoint[0], prevPoint[1]);
        this.mLine.setSecondVertex(x, y);
        this.mLine.draw(aCamera);

        theta = theta + deltaTheta;
        prevPoint[0] = x;
        prevPoint[1] = y;
    }
};